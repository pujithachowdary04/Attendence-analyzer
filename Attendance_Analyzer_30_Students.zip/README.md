# Student Attendance Analyzer

1. Open this folder in VS Code.
2. In the terminal, run: `pip install -r requirements.txt`
3. Start the dashboard: `python -m streamlit run app.py`
4. Open the local URL shown in the terminal (usually http://localhost:8501).

The dashboard includes 30 fictional sample students, a configurable attendance threshold, charts, search/filter, a shortage list, and CSV download.
