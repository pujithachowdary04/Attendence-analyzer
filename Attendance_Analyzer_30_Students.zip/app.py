import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="Student Attendance Analyzer", page_icon="🎓", layout="wide")

# Fictional sample data for 30 students. Replace these values with real class records.
students = [
    ("STU001", "Aarav Sharma", 38), ("STU002", "Aadhya Reddy", 35),
    ("STU003", "Aditya Kumar", 32), ("STU004", "Ananya Rao", 39),
    ("STU005", "Arjun Varma", 28), ("STU006", "Bhavana Patel", 36),
    ("STU007", "Charan Teja", 30), ("STU008", "Deepika Singh", 37),
    ("STU009", "Esha Gupta", 33), ("STU010", "Farhan Ali", 25),
    ("STU011", "Gowtham Reddy", 40), ("STU012", "Harini Das", 34),
    ("STU013", "Ishaan Verma", 29), ("STU014", "Jahnavi Rao", 38),
    ("STU015", "Karthik Nair", 31), ("STU016", "Lavanya Reddy", 36),
    ("STU017", "Manoj Kumar", 27), ("STU018", "Niharika Shah", 39),
    ("STU019", "Pavan Kalyan", 34), ("STU020", "Keerthi Lakshmi", 22),
    ("STU021", "Rahul Mehta", 37), ("STU022", "Saanvi Iyer", 32),
    ("STU023", "Tarun Kumar", 30), ("STU024", "Uma Mahesh", 35),
    ("STU025", "Varun Raju", 26), ("STU026", "Wahida Begum", 38),
    ("STU027", "Yashwanth Rao", 33), ("STU028", "Zoya Khan", 29),
    ("STU029", "Sai Teja", 36), ("STU030", "Pooja Sharma", 31),
]

DEFAULT_THRESHOLD = 75
st.title("🎓 Student Attendance Analyzer")
st.caption("Attendance dashboard • 30-student sample dataset")

with st.sidebar:
    st.header("Dashboard settings")
    threshold = st.slider("Minimum attendance threshold (%)", 1, 100, DEFAULT_THRESHOLD)
    st.caption("Demo data — edit the student values in app.py to match your class.")

df = pd.DataFrame(students, columns=["Student ID", "Student Name", "Classes Attended"])
df["Total Classes"] = 40
df["Attendance (%)"] = (df["Classes Attended"] / df["Total Classes"] * 100).round(1)
df["Status"] = df["Attendance (%)"].apply(lambda x: "Eligible" if x >= threshold else "Shortage")

total_students = len(df)
average_attendance = df["Attendance (%)"].mean()
eligible = int((df["Attendance (%)"] >= threshold).sum())
shortage = total_students - eligible

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Students", total_students)
c2.metric("Average Attendance", f"{average_attendance:.1f}%")
c3.metric("Eligible Students", eligible)
c4.metric("Attendance Shortage", shortage)

st.divider()
left, right = st.columns([1.35, 1])
with left:
    st.subheader("Attendance by student")
    chart_df = df.sort_values("Attendance (%)", ascending=False)
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.bar(chart_df["Student ID"], chart_df["Attendance (%)"])
    ax.axhline(threshold, linestyle="--", label=f"Threshold: {threshold}%")
    ax.set_ylabel("Attendance (%)")
    ax.set_ylim(0, 105)
    ax.tick_params(axis="x", rotation=90, labelsize=8)
    ax.legend()
    ax.grid(axis="y", alpha=0.2)
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)

with right:
    st.subheader("Attendance status")
    counts = df["Status"].value_counts().reindex(["Eligible", "Shortage"], fill_value=0)
    fig2, ax2 = plt.subplots(figsize=(5, 4))
    ax2.pie(counts.values, labels=counts.index, autopct="%1.0f%%", startangle=90)
    ax2.axis("equal")
    st.pyplot(fig2, use_container_width=True)
    plt.close(fig2)

st.divider()
st.subheader("Student attendance records")
search = st.text_input("Search by student name or ID")
status_filter = st.selectbox("Filter students", ["All", "Eligible", "Shortage"])
filtered = df.copy()
if search:
    filtered = filtered[
        filtered["Student Name"].str.contains(search, case=False, na=False)
        | filtered["Student ID"].str.contains(search, case=False, na=False)
    ]
if status_filter != "All":
    filtered = filtered[filtered["Status"] == status_filter]

st.dataframe(
    filtered[["Student ID", "Student Name", "Classes Attended", "Total Classes", "Attendance (%)", "Status"]],
    use_container_width=True,
    hide_index=True
)

st.subheader("Students below the attendance threshold")
shortage_df = df[df["Attendance (%)"] < threshold][
    ["Student ID", "Student Name", "Attendance (%)"]
].sort_values("Attendance (%)")
if shortage_df.empty:
    st.success("All students meet the selected attendance threshold.")
else:
    st.dataframe(shortage_df, use_container_width=True, hide_index=True)

csv = df.to_csv(index=False).encode("utf-8")
st.download_button("⬇️ Download attendance report (CSV)", csv,
                   "attendance_report_30_students.csv", "text/csv")

st.info("These are fictional sample records for demonstration, not real student attendance.")
